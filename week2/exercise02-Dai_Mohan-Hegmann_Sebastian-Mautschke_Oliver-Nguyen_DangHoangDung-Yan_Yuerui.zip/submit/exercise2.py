import numpy as np

# importing vtk is required for correctly setting up object factories
import vtk
# import VTK classes from their respective modules
# these could also be imported from the vtk module, but it would break support for auto-completion
#   For finding the module, that a class belongs to, search for its source file in the VTK source code.
#   The module name is put together from the path.
#   E.g., vtkGlyph3D.h is located in directory VTK/Filters/Core/, thus its module is called vtkFiltersCore.
from vtkmodules.vtkCommonCore import vtkCommand
from vtkmodules.vtkCommonDataModel import vtkDataObject
from vtkmodules.vtkFiltersCore import (
    vtkGlyph3D,
    vtkMaskPoints,
)
from vtkmodules.vtkFiltersModeling import vtkOutlineFilter
from vtkmodules.vtkFiltersSources import (
    vtkArrowSource,
    vtkConeSource,
    vtkLineSource,
)
from vtkmodules.vtkImagingCore import vtkExtractVOI
from vtkmodules.vtkInteractionStyle import vtkInteractorStyleTrackballCamera
from vtkmodules.vtkInteractionWidgets import (
    vtkSliderWidget,
    vtkSliderRepresentation2D,
)
from vtkmodules.vtkIOXML import vtkXMLImageDataReader
from vtkmodules.vtkRenderingCore import (
    vtkActor,
    vtkPolyDataMapper,
    vtkRenderer,
    vtkRenderWindow,
    vtkRenderWindowInteractor,
)


# helper function for part (e) of the exercise
def make_slider(interactor, callback, title, initial_value, value_range, point1=(.1, .9), point2=(.9, .9)):
    """
    Creates a slider widget. Example usage:

    def slider_callback(value):
        print(value)
    slider = make_slider(interactor, slider_callback, 'My Slider', 32, (0, 64))

    The return value must be stored in a variable to avoid garbage collection.
    """
    slider_rep = vtkSliderRepresentation2D()
    slider_rep.SetPickable(False)
    slider_rep.SetMinimumValue(value_range[0])
    slider_rep.SetMaximumValue(value_range[1])
    slider_rep.SetValue(initial_value)
    slider_rep.SetTitleText(title)
    slider_rep.GetPoint1Coordinate().SetCoordinateSystemToNormalizedViewport()
    slider_rep.GetPoint1Coordinate().SetValue(*point1)
    slider_rep.GetPoint2Coordinate().SetCoordinateSystemToNormalizedViewport()
    slider_rep.GetPoint2Coordinate().SetValue(*point2)
    slider_rep.SetSliderLength(0.01)
    slider_rep.SetSliderWidth(0.05)
    slider_rep.SetEndCapLength(0.005)
    slider_rep.SetEndCapWidth(0.05)
    slider_widget = vtkSliderWidget()
    slider_widget.SetRepresentation(slider_rep)
    slider_widget.SetInteractor(interactor)
    slider_widget.On()

    def callback_wrapper(caller, event):
        value = caller.GetRepresentation().GetValue()
        callback(value)

    slider_widget.AddObserver(vtkCommand.InteractionEvent, callback_wrapper)
    callback(initial_value)
    return slider_widget


def main():
    # read the provided dataset
    reader = vtkXMLImageDataReader()
    reader.SetFileName('field.vti')
    # calling reader.Update() makes the output data object available via reader.GetOutput()
    reader.Update()
    # get information about input dataset here
    print(reader.GetOutput()) #a)

    # insert a vtkExtractVOI filter #c)
    extract = vtkExtractVOI()
    # connect to the reader's output
    extract.SetInputConnection(reader.GetOutputPort())
    # set VOI with the value of input dataset's extent
    extract.SetVOI((0, 63, 0, 63, 0, 63))
    # set i_min = i_max
    extract.SetVOI((63, 63, 0, 63, 0, 63))

    # reduce the number of data points by randomly selecting points
    mask = vtkMaskPoints()
    # connect to the reader's output
    mask.SetInputConnection(reader.GetOutputPort())
    # set filter parameters
    mask.SetMaximumNumberOfPoints(50) #b)
    mask.RandomModeOn()

    # create a source that generates glyph geometry
    #line_source = vtkLineSource()
    # try cone source
    #cone_source = vtkConeSource() #b)
    # try arrow source
    arrow_source = vtkArrowSource() #b)

    # generate a glyph from a geometry source for each input point
    glyph = vtkGlyph3D()
    # connect geometry source #b)
    #glyph.SetSourceConnection(line_source.GetOutputPort())
    #glyph.SetSourceConnection(cone_source.GetOutputPort())
    glyph.SetSourceConnection(arrow_source.GetOutputPort())
    # connect input
    glyph.SetInputConnection(mask.GetOutputPort())
    # set point data array 'u' of the input as input vectors (id=1) for the filter
    glyph.SetInputArrayToProcess(1, 0, 0, vtkDataObject.FIELD_ASSOCIATION_POINTS, 'u')
    # set filter parameters
    glyph.ScalingOn()
    glyph.SetScaleModeToScaleByVector()
    glyph.OrientOn()
    # set scale factor of the vtkGlyph3D #b)
    glyph.SetScaleFactor(0.25)

    #d) display outline of the input data using vtkOutlineFilter
    outfilter = vtkOutlineFilter()
    # set its input to the reader output
    outfilter.SetInputConnection(reader.GetOutputPort())

    # map the glyph geometry to graphics primitives
    mapper = vtkPolyDataMapper()
    mapper.SetInputConnection(glyph.GetOutputPort())
    # create entity in render scene
    actor = vtkActor()
    actor.SetMapper(mapper)

    # renders a collection of vtkActors
    renderer = vtkRenderer()
    # add actors to be rendered
    renderer.AddActor(actor)
    # set background color
    renderer.SetBackground(82/255., 87/255., 110/255.)

    # create render window
    render_window = vtkRenderWindow()
    render_window.AddRenderer(renderer)
    render_window.SetSize(500, 500)

    # create interactor, that handles user input
    interactor = vtkRenderWindowInteractor()
    interactor.SetRenderWindow(render_window)

    # set input style
    interactor_style = vtkInteractorStyleTrackballCamera()
    interactor.SetInteractorStyle(interactor_style)

    # e) call make_slider function
    slider_widget = make_slider(interactor, print, 'Slider 5', 20, (1,65))

    # run event loop
    interactor.Start()


if __name__ == '__main__':
    main()
